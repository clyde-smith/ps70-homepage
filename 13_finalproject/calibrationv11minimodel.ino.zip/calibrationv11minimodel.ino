#include <Wire.h>
#include <WiFi.h>
#include <WebServer.h>
#include <Preferences.h>
#include <Adafruit_VL53L0X.h>
#include <math.h>

// ------------------------------------------------------------
//                PINS & WIFI CONFIG
// ------------------------------------------------------------
static const uint8_t SDA_PIN = 22;  
static const uint8_t SCL_PIN = 21;

const char* AP_SSID = "ESP32-Distance";
const char* AP_PASS = "distance1";

// ------------------------------------------------------------
//     SENSOR + FILTER TUNING (MODEL VERSION: 5–10 lb range)
// ------------------------------------------------------------
static const uint32_t SAMPLE_MS     = 200;   // sample ~5 Hz
static const uint8_t  MED_WIN       = 11;    // median window size (odd)
static const float    MM_JITTER_EST = 5.0f;  // expected mechanical jitter (mm)

// Smoothing (EMA on grams)
static const float    G_PER_LB      = 453.59237f;
static const float    ALPHA_SLOW    = 0.02f;
static const float    ALPHA_FAST    = 0.08f;

// Deadband for model-scale range (smaller -> more sensitive)
static const float    BASE_DEAD_LB  = 0.05f;  // ~0.05 lb
static const float    BASE_DEAD_KG  = 0.02f;  // ~20 g

// “Big jump” threshold (for small range)
static const float    JUMP_LB       = 1.0f;   // ~1 lb jump

// Force update if distance changes by >= this many mm
static const uint16_t MM_STEP_TRIGGER = 1;    // 1 mm step

// ------------------------------------------------------------
//                    SENSOR CLASS
// ------------------------------------------------------------
WebServer   server(80);
Preferences prefs;

class VL53Task {
public:
  VL53Task(uint8_t sda, uint8_t scl, uint32_t dt_ms)
  : _sda(sda), _scl(scl), _dt(dt_ms) {}

  bool begin() {
    Wire.begin(_sda, _scl);
    Wire.setClock(100000);

    _ok = _lox.begin(0x29, false);
    if (!_ok) Serial.println(F("VL53L0X init failed"));
    return _ok;
  }

  void update() {
    if (!_ok) return;

    uint32_t now = millis();
    if (now - _last < _dt) return;
    _last = now;

    VL53L0X_RangingMeasurementData_t m;
    _lox.rangingTest(&m, false);

    if (m.RangeStatus == 4) {
      _oor = true;
      pushMM(0);
    } else {
      _oor = false;
      pushMM((uint16_t)m.RangeMilliMeter);
    }
  }

  bool oor() const { return _oor; }
  uint16_t mmMedian() const { return _mm_med; }

private:
  void pushMM(uint16_t mm) {
    _buf[_i] = mm;
    _i = (_i + 1) % MED_WIN;
    if (_count < MED_WIN) _count++;

    uint16_t tmp[MED_WIN];
    for (uint8_t k = 0; k < _count; k++) tmp[k] = _buf[k];

    // insertion sort
    for (uint8_t a = 1; a < _count; a++) {
      uint16_t key = tmp[a];
      int8_t b = a - 1;
      while (b >= 0 && tmp[b] > key) {
        tmp[b + 1] = tmp[b];
        b--;
      }
      tmp[b + 1] = key;
    }

    _mm_med = tmp[(_count - 1) / 2];
  }

  Adafruit_VL53L0X _lox;
  uint8_t  _sda, _scl;
  uint32_t _dt, _last = 0;
  bool     _ok = false, _oor = true;

  uint16_t _buf[MED_WIN] = {0};
  uint8_t  _i = 0, _count = 0;
  uint16_t _mm_med = 0;
};

VL53Task ranger(SDA_PIN, SCL_PIN, SAMPLE_MS);

// ------------------------------------------------------------
//                CALIBRATION STORAGE (GRAMS)
// ------------------------------------------------------------
struct CalPt { uint16_t mm; float g; };
static const uint8_t CAL_MAX = 64;
CalPt  cal[CAL_MAX];
uint8_t calN = 0;

enum UnitMode : uint8_t { UNIT_KG = 0, UNIT_LB = 1 };
UnitMode unitMode = UNIT_LB;  // default

float gramsFromUnit(float v) {
  return (unitMode == UNIT_KG) ? v * 1000.0f : v * G_PER_LB;
}
float unitFromGrams(float g) {
  return (unitMode == UNIT_KG) ? g / 1000.0f : g / G_PER_LB;
}
float baseDeadbandUnit() {
  return (unitMode == UNIT_KG) ? BASE_DEAD_KG : BASE_DEAD_LB;
}
float gToLb(float g) { return g / G_PER_LB; }
float lbToG(float lb){ return lb * G_PER_LB; }
const char* unitName() { return (unitMode == UNIT_KG) ? "kg" : "lb"; }

void loadCal() {
  calN = 0;
  if (!prefs.begin("vl53scale", true)) return;

  calN = prefs.getUChar("n", 0);
  if (calN > CAL_MAX) calN = 0;

  for (uint8_t i = 0; i < calN; i++) {
    char kmm[8], kg[8];
    snprintf(kmm, sizeof(kmm), "m%u", i);
    snprintf(kg,  sizeof(kg),  "g%u", i);
    cal[i].mm = prefs.getUShort(kmm, 0);
    cal[i].g  = prefs.getFloat(kg,   0.f);
  }

  String u = prefs.getString("unit", "lb");
  unitMode = (u == "kg") ? UNIT_KG : UNIT_LB;

  prefs.end();

  // sort by mm ascending
  for (uint8_t i = 0; i < calN; i++) {
    for (uint8_t j = i + 1; j < calN; j++) {
      if (cal[j].mm < cal[i].mm) {
        CalPt t = cal[i];
        cal[i] = cal[j];
        cal[j] = t;
      }
    }
  }
}

void saveCal() {
  if (!prefs.begin("vl53scale", false)) return;

  prefs.putUChar("n", calN);
  for (uint8_t i = 0; i < calN; i++) {
    char kmm[8], kg[8];
    snprintf(kmm, sizeof(kmm), "m%u", i);
    snprintf(kg,  sizeof(kg),  "g%u", i);
    prefs.putUShort(kmm, cal[i].mm);
    prefs.putFloat( kg, cal[i].g);
  }
  prefs.putString("unit", (unitMode == UNIT_KG) ? "kg" : "lb");
  prefs.end();
}

void clearCal() {
  calN = 0;
  saveCal();
}

void insertCal(uint16_t mm, float g) {
  uint8_t pos = 0;
  while (pos < calN && cal[pos].mm < mm) pos++;

  if (calN < CAL_MAX) {
    for (int i = calN; i > (int)pos; i--) cal[i] = cal[i - 1];
    cal[pos] = {mm, g};
    calN++;
  } else {
    cal[(pos == calN) ? (calN - 1) : pos] = {mm, g};
  }
}

// piecewise linear grams -> mm
float gramsFromMM(uint16_t mm) {
  if (calN == 0) return 0.f;
  if (calN == 1) return cal[0].g;

  if (mm <= cal[0].mm)         return cal[0].g;
  if (mm >= cal[calN - 1].mm)  return cal[calN - 1].g;

  for (uint8_t i = 1; i < calN; i++) {
    if (mm <= cal[i].mm) {
      float x0 = cal[i - 1].mm, y0 = cal[i - 1].g;
      float x1 = cal[i].mm,     y1 = cal[i].g;
      float t = (mm - x0) / (x1 - x0);
      return y0 + t * (y1 - y0);
    }
  }
  return cal[calN - 1].g;
}

// slope in lb/mm
float slopeLbPerMm(uint16_t mm) {
  if (calN < 2) return 0.f;

  if (mm <= cal[0].mm) {
    float dx = (float)(cal[1].mm - cal[0].mm);
    float dy_lb = gToLb(cal[1].g - cal[0].g);
    return (dx != 0.f) ? (dy_lb / dx) : 0.f;
  }
  if (mm >= cal[calN - 1].mm) {
    float dx = (float)(cal[calN - 1].mm - cal[calN - 2].mm);
    float dy_lb = gToLb(cal[calN - 1].g - cal[calN - 2].g);
    return (dx != 0.f) ? (dy_lb / dx) : 0.f;
  }

  for (uint8_t i = 1; i < calN; i++) {
    if (mm <= cal[i].mm) {
      float dx = (float)(cal[i].mm - cal[i - 1].mm);
      float dy_lb = gToLb(cal[i].g - cal[i - 1].g);
      return (dx != 0.f) ? (dy_lb / dx) : 0.f;
    }
  }
  return 0.f;
}

// ------------------------------------------------------------
//                DISPLAY SMOOTHING LOGIC
// ------------------------------------------------------------
float g_slow = 0.f;   
bool  slow_valid = false;
float w_disp = 0.f;      
uint32_t last_jump_ms = 0;

uint16_t last_mm_for_disp = 0;
bool     disp_mm_valid    = false;

float jumpThreshG() { return lbToG(JUMP_LB); }

float dynamicDeadbandUnit(uint16_t mm) {
  float slope_lb_per_mm = fabsf(slopeLbPerMm(mm));
  float dyn_lb = baseDeadbandUnit() + slope_lb_per_mm * (MM_JITTER_EST * 0.5f);
  if (unitMode == UNIT_KG) return dyn_lb * 0.45359237f;
  return dyn_lb;
}

void refreshFilters() {
  if (ranger.oor()) return;

  uint16_t mm = ranger.mmMedian();
  float    g_in = gramsFromMM(mm);

  if (slow_valid && fabsf(g_in - g_slow) > jumpThreshG()) {
    last_jump_ms = millis();
  }

  float alpha = ALPHA_SLOW;
  if (millis() - last_jump_ms < 1500) {
    alpha = ALPHA_FAST;
  }

  if (!slow_valid) {
    g_slow = g_in;
    slow_valid = true;
  } else {
    g_slow += alpha * (g_in - g_slow);
  }

  float w_cur = unitFromGrams(g_slow);
  float db    = dynamicDeadbandUnit(mm);

  if (!disp_mm_valid) {
    w_disp = w_cur;
    last_mm_for_disp = mm;
    disp_mm_valid = true;
    return;
  }

  // Force update if median mm moved by ≥ 1 mm
  if ((uint16_t)abs((int)mm - (int)last_mm_for_disp) >= MM_STEP_TRIGGER) {
    w_disp = w_cur;
    last_mm_for_disp = mm;
    return;
  }

  // Otherwise run deadband in current units
  if (!isnan(w_cur) && (fabsf(w_cur - w_disp) >= db)) {
    w_disp = w_cur;
    last_mm_for_disp = mm;
  }
}

// ------------------------------------------------------------
//                         HTML PAGES
// ------------------------------------------------------------
const char HOME_HTML[] PROGMEM = R"HTML(
<!doctype html><html><head>
<meta name=viewport content="width=device-width,initial-scale=1">
<title>Weight</title>
<style>
  :root{--bg:#0f1115;--card:#171a21;--ink:#e9eef5;--mut:#9aa5b1;}
  body{margin:0;background:var(--bg);color:var(--ink);font:16px system-ui;}
  .bar{position:fixed;top:0;right:0;padding:12px}
  .bar a{background:#4fb3ff;color:#001725;text-decoration:none;font-weight:700;
         padding:10px 14px;border-radius:10px}
  .wrap{display:flex;justify-content:center;align-items:flex-start;
        min-height:100vh;padding-top:70px}
  .card{background:var(--card);padding:20px 26px;
        border-radius:16px;text-align:center;min-width:280px}
  .big{font-size:64px;font-weight:800}
  .sub{color:var(--mut);margin-top:8px}
</style></head><body>
  <div class=bar><a href="/cal">Calibrate</a></div>
  <div class=wrap>
    <div class=card>
      <div class=big id=val>--</div>
      <div class=sub>Distance: <span id=mm>--</span> mm</div>
    </div>
  </div>
<script>
async function getJSON(u){return (await fetch(u,{cache:"no-store"})).json();}
async function refresh(){
  try{
    const s = await getJSON("/state");
    const valEl = document.getElementById("val");
    const mmEl  = document.getElementById("mm");
    if(s.oor){
      valEl.textContent = "out of range";
      mmEl.textContent  = "--";
    }else{
      const fixed = (s.unit === "kg") ? 3 : 2;
      valEl.textContent = s.w_disp.toFixed(fixed) + " " + s.unit;
      mmEl.textContent  = s.mm_med;
    }
  }catch(e){}
}
setInterval(refresh, 800); 
refresh();
</script>
</body></html>
)HTML";

const char CAL_HTML[] PROGMEM = R"HTML(
<!doctype html><html><head>
<meta name=viewport content="width=device-width,initial-scale=1">
<title>Calibration</title>
<style>
  body{background:#0f1115;color:#e9eef5;font:16px system-ui;margin:0}
  .wrap{max-width:880px;margin:auto;padding:24px}
  a{color:#9cc9ff;text-decoration:none}
  .row{display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap}
  .seg button{padding:8px 12px}
  .seg button.active{background:#4fb3ff;color:#000;border-radius:8px}
  .card{background:#171a21;padding:20px;border-radius:16px;margin-top:12px}
  input{padding:10px;border-radius:10px;border:1px solid #2a2f3a;
        background:#0c0f14;color:white;width:180px}
  button{padding:10px 14px;border-radius:10px;font-weight:700;background:#4fb3ff;color:#000}
  .alt{background:#263042;color:#fff}
  table{width:100%;margin-top:10px;border-collapse:collapse}
  td,th{padding:8px;border-bottom:1px solid #232a36;color:#9aa5b1}
</style></head>
<body><div class=wrap>

  <div class=row>
    <a href="/">&larr; Back</a>
    <div class=seg>
      <button id=btnKg>kg</button>
      <button id=btnLb>lb</button>
    </div>
  </div>

  <div class=card>
    <h2>Calibrate (<span id=unitLbl>lb</span>)</h2>
    <div class=row style="margin-top:10px">
      <input id=win type=number step=0.01 placeholder="weight">
      <button id=add>Capture</button>
      <button id=save class=alt>Save</button>
      <button id=clear class=alt>Clear</button>
    </div>
    <table><thead><tr><th>mm</th><th>value</th></tr></thead><tbody id=tbl></tbody></table>
  </div>

</div>
<script>
async function getJSON(u){return (await fetch(u,{cache:"no-store"})).json();}
let UNIT = "lb";

function setUnitUI(u){
  UNIT = u;
  document.getElementById("unitLbl").textContent = u;
  document.getElementById("win").step = (u === "kg") ? "0.001" : "0.01";
  document.getElementById("btnKg").classList.toggle("active", u === "kg");
  document.getElementById("btnLb").classList.toggle("active", u === "lb");
}

async function refreshUnit(){
  const s = await getJSON("/unit");
  setUnitUI(s.unit);
}

async function loadPoints(){
  const p = await getJSON("/cal/list");
  setUnitUI(p.unit);
  const tbody = document.getElementById("tbl");
  tbody.innerHTML = "";
  const fixed = (p.unit === "kg") ? 3 : 2;
  (p.points || []).forEach(pt => {
    const tr = document.createElement("tr");
    tr.innerHTML = `<td>${pt.mm}</td><td>${pt.val.toFixed(fixed)} ${p.unit}</td>`;
    tbody.appendChild(tr);
  });
}

document.getElementById("add").onclick = async () => {
  const v = parseFloat(document.getElementById("win").value);
  if (isNaN(v)) return alert("Enter a weight first");
  const url = (UNIT === "kg") ? `/cal/add?kg=${encodeURIComponent(v)}` :
                                `/cal/add?lb=${encodeURIComponent(v)}`;
  await fetch(url, {method:"POST"});
  document.getElementById("win").value = "";
  loadPoints();
};
document.getElementById("save").onclick  = async () => { await fetch("/cal/save",  {method:"POST"}); loadPoints(); };
document.getElementById("clear").onclick = async () => { await fetch("/cal/clear", {method:"POST"}); loadPoints(); };

document.getElementById("btnKg").onclick = async () => {
  await fetch("/unit/set?u=kg", {method:"POST"});
  await refreshUnit();
  await loadPoints();
};
document.getElementById("btnLb").onclick = async () => {
  await fetch("/unit/set?u=lb", {method:"POST"});
  await refreshUnit();
  await loadPoints();
};

refreshUnit();
loadPoints();
</script></body></html>
)HTML";

// ------------------------------------------------------------
//                        HTTP HANDLERS
// ------------------------------------------------------------
void handleHome()  { server.send(200, "text/html", HOME_HTML); }
void handleCalPage(){ server.send(200, "text/html", CAL_HTML); }

void handleState() {
  // keep sensor + filters up to date
  ranger.update();
  refreshFilters();

  const bool oor = ranger.oor();
  const uint16_t mm = ranger.mmMedian();

  String s = "{";
  s += "\"unit\":\""; s += unitName(); s += "\",";
  s += "\"oor\":";
  s += (oor ? "true" : "false");
  s += ",";
  s += "\"mm_med\":"; s += String(mm); s += ",";
  s += "\"w_disp\":"; s += String(w_disp, 6);
  s += "}";
  server.send(200, "application/json", s);
}

void handleCalList() {
  String s = "{\"unit\":\"";
  s += unitName();
  s += "\",\"points\":[";
  for (uint8_t i = 0; i < calN; i++) {
    if (i) s += ",";
    s += "{\"mm\":";  s += cal[i].mm;
    s += ",\"val\":"; s += String(unitFromGrams(cal[i].g), 6);
    s += "}";
  }
  s += "]}";
  server.send(200, "application/json", s);
}

void handleCalAdd() {
  float g = NAN;
  if      (server.hasArg("kg")) g = server.arg("kg").toFloat() * 1000.0f;
  else if (server.hasArg("lb")) g = server.arg("lb").toFloat() * G_PER_LB;
  else if (server.hasArg("g"))  g = server.arg("g").toFloat();
  else { server.send(400, "text/plain", "missing kg/lb"); return; }

  if (isnan(g)) { server.send(400, "text/plain", "bad value"); return; }

  uint16_t mm = ranger.mmMedian();
  insertCal(mm, g);
  saveCal();

  // recenter filters
  g_slow         = g;
  slow_valid     = true;
  w_disp         = unitFromGrams(g);
  last_mm_for_disp = mm;
  disp_mm_valid  = true;

  server.send(200, "application/json", "{\"ok\":true}");
}

void handleCalClear() {
  clearCal();
  slow_valid    = false;
  w_disp        = 0;
  disp_mm_valid = false;
  server.send(200, "application/json", "{\"ok\":true}");
}

void handleCalSave() {
  saveCal();
  server.send(200, "application/json", "{\"ok\":true}");
}

void handleUnitSet() {
  if (!server.hasArg("u")) { server.send(400,"text/plain","missing u=kg|lb"); return; }
  String u = server.arg("u");
  unitMode = (u == "kg") ? UNIT_KG : UNIT_LB;
  saveCal();
  if (slow_valid) {
    w_disp = unitFromGrams(g_slow);
  }
  server.send(200, "application/json", "{\"ok\":true}");
}

void handleUnitGet() {
  String s = "{\"unit\":\"";
  s += unitName();
  s += "\"}";
  server.send(200, "application/json", s);
}

void handleDistance() {
  ranger.update();
  if (ranger.oor()) server.send(200, "text/plain", "out_of_range");
  else              server.send(200, "text/plain", String(ranger.mmMedian()));
}

// ------------------------------------------------------------
//                        SETUP & LOOP
// ------------------------------------------------------------
void setup() {
  Serial.begin(115200);
  Serial.println(F("\nModel-scale Distance→Weight (SDA=22, SCL=21)"));

  ranger.begin();
  loadCal();

  WiFi.mode(WIFI_AP);
  WiFi.softAP(AP_SSID, AP_PASS);
  Serial.print("AP IP: "); Serial.println(WiFi.softAPIP());

  server.on("/",          handleHome);
  server.on("/cal",       handleCalPage);
  server.on("/state",     handleState);
  server.on("/cal/list",  handleCalList);
  server.on("/cal/add",   HTTP_POST, handleCalAdd);
  server.on("/cal/clear", HTTP_POST, handleCalClear);
  server.on("/cal/save",  HTTP_POST, handleCalSave);
  server.on("/unit/set",  HTTP_POST, handleUnitSet);
  server.on("/unit",      handleUnitGet);
  server.on("/distance",  handleDistance);  // legacy

  server.begin();
  Serial.println("Web server started");
}

void loop() {
  ranger.update();
  refreshFilters();
  server.handleClient();
}
