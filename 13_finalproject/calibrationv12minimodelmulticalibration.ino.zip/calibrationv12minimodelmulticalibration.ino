#include <Wire.h>
#include <WiFi.h>
#include <WebServer.h>
#include <Preferences.h>
#include <Adafruit_VL53L0X.h>
#include <math.h>

// ---------------- Pins & Wi-Fi ----------------
static const uint8_t SDA_PIN = 22;  // per your wiring
static const uint8_t SCL_PIN = 21;

const char* AP_SSID = "ESP32-ModelScale";
const char* AP_PASS = "distance1";

// ---------------- Sensor & Filter Tuning (mini model) ------------------
// Model version: ~5–10 lb range, small distance span (~20 mm)
static const uint32_t SAMPLE_MS      = 200;  // sensor sample period (ms)
static const uint8_t  MED_WIN        = 7;    // median window (odd, small)
static const float    MM_JITTER_EST  = 1.5f; // expected distance noise (mm)

// Smoothing parameters
static const float    G_PER_LB       = 453.59237f;
static const float    ALPHA_SLOW     = 0.08f;   // baseline EMA in grams (mini scale)
static const float    ALPHA_FAST     = 0.20f;   // temporarily after big jump

// Deadbands (base; dynamic part added from local slope)
static const float    BASE_DEAD_LB   = 0.05f;   // ~0.05 lb
static const float    BASE_DEAD_KG   = 0.025f;  // ~0.055 lb

// “Big jump” heuristic for speeding EMA
static const float    JUMP_LB        = 1.0f;    // ~1 lb jump is "big" for mini scale

// Force display update if median distance moves a bit
static const uint16_t MM_STEP_TRIGGER = 1;      // 1 mm

// Calibration capture window (for 5-second average)
static const uint32_t CAL_CAPTURE_MS  = 5000;   // ms to average distance during calibration

// ---------------- Web & Storage --------------
WebServer   server(80);
Preferences prefs;

// ---------------- Sensor Task ----------------
class VL53Task {
public:
  VL53Task(uint8_t sda, uint8_t scl, uint32_t dt_ms)
  : _sda(sda), _scl(scl), _dt(dt_ms) {}

  bool begin() {
    Wire.begin(_sda, _scl);
    Wire.setClock(100000);
    _ok = _lox.begin(0x29, false);
    if (!_ok) Serial.println(F("VL53L0X init failed"));
    return _ok;
  }

  void update() {
    if (!_ok) return;
    uint32_t now = millis();
    if (now - _last < _dt) return;
    _last = now;

    VL53L0X_RangingMeasurementData_t m;
    _lox.rangingTest(&m, false);
    if (m.RangeStatus == 4) {
      _oor = true;
      pushMM(0);
    } else {
      _oor = false;
      pushMM((uint16_t)m.RangeMilliMeter);
    }
  }

  bool     oor()      const { return _oor; }
  uint16_t mmMedian() const { return _mm_med; }

private:
  void pushMM(uint16_t mm) {
    _buf[_i] = mm;
    _i = (_i + 1) % MED_WIN;
    if (_count < MED_WIN) _count++;

    uint16_t tmp[MED_WIN];
    for (uint8_t k = 0; k < _count; ++k) tmp[k] = _buf[k];
    // insertion sort
    for (uint8_t a = 1; a < _count; ++a) {
      uint16_t key = tmp[a];
      int8_t b = a - 1;
      while (b >= 0 && tmp[b] > key) {
        tmp[b+1] = tmp[b];
        --b;
      }
      tmp[b+1] = key;
    }
    _mm_med = tmp[_count ? (_count - 1) / 2 : 0];
  }

  Adafruit_VL53L0X _lox;
  uint8_t  _sda, _scl;
  uint32_t _dt, _last = 0;
  bool     _ok = false, _oor = true;

  uint16_t _buf[MED_WIN] = {0};
  uint8_t  _i = 0, _count = 0;
  uint16_t _mm_med = 0;
};

VL53Task ranger(SDA_PIN, SCL_PIN, SAMPLE_MS);

// ---------------- Calibration (stored in grams) -----------
struct CalPt { uint16_t mm; float g; };
static const uint8_t CAL_MAX      = 64;
CalPt  cal[CAL_MAX];
uint8_t calN = 0;

// Units
enum UnitMode : uint8_t { UNIT_KG = 0, UNIT_LB = 1 };
UnitMode unitMode = UNIT_LB;  // default to lb

float gramsFromUnit(float v) {
  return (unitMode == UNIT_KG) ? (v * 1000.0f) : (v * G_PER_LB);
}
float unitFromGrams(float g) {
  return (unitMode == UNIT_KG) ? (g / 1000.0f) : (g / G_PER_LB);
}
float baseDeadbandUnit() {
  return (unitMode == UNIT_KG) ? BASE_DEAD_KG : BASE_DEAD_LB;
}
float lbToG(float lb){ return lb * G_PER_LB; }
float gToLb(float g){ return g / G_PER_LB; }
const char* unitName(){ return (unitMode == UNIT_KG) ? "kg" : "lb"; }

// -------- Multi-profile support ----------
static const uint8_t MAX_PROFILES = 5;

struct ProfileMeta {
  String name;
  bool   hasCal;
};

ProfileMeta profiles[MAX_PROFILES];
uint8_t profileCount  = 0;
int8_t  activeProfile = -1;  // -1 = none / unsaved

// Smoothing / display state
float    g_slow           = 0.f;
bool     slow_valid       = false;
float    w_disp           = 0.f;  // display value in current units
uint32_t last_jump_ms     = 0;
uint16_t last_mm_for_disp = 0;
bool     disp_mm_valid    = false;

float jumpThreshG(){ return lbToG(JUMP_LB); }

// ----------------------------------------------------------------------
//  Calibration array helpers
// ----------------------------------------------------------------------
void clearCalArray() {
  calN = 0;
}

void insertCal(uint16_t mm, float g){
  uint8_t pos = 0;
  while (pos < calN && cal[pos].mm < mm) pos++;
  if (calN < CAL_MAX) {
    for (int i = calN; i > pos; --i) cal[i] = cal[i-1];
    cal[pos] = {mm, g};
    calN++;
  } else {
    cal[(pos == calN) ? (calN-1) : pos] = {mm, g};
  }
}

void deleteCalAt(uint8_t idx) {
  if (idx >= calN) return;
  for (uint8_t i = idx; i + 1 < calN; ++i) {
    cal[i] = cal[i+1];
  }
  calN--;
}

// piecewise linear grams from mm (clamped)
float gramsFromMM(uint16_t mm){
  if (calN == 0) return 0.f;
  if (calN == 1) return cal[0].g;
  if (mm <= cal[0].mm)          return cal[0].g;
  if (mm >= cal[calN-1].mm)     return cal[calN-1].g;
  for (uint8_t i = 1; i < calN; i++){
    if (mm <= cal[i].mm){
      float x0 = cal[i-1].mm, y0 = cal[i-1].g;
      float x1 = cal[i].mm,   y1 = cal[i].g;
      float t  = (mm - x0) / (x1 - x0);
      return y0 + t * (y1 - y0);
    }
  }
  return cal[calN-1].g;
}

// local slope in lb/mm near mm
float slopeLbPerMm(uint16_t mm){
  if (calN < 2) return 0.0f;
  if (mm <= cal[0].mm){
    float dx = (float)(cal[1].mm - cal[0].mm);
    float dy_lb = gToLb(cal[1].g - cal[0].g);
    return (dx != 0) ? (dy_lb / dx) : 0.0f;
  }
  if (mm >= cal[calN-1].mm){
    float dx = (float)(cal[calN-1].mm - cal[calN-2].mm);
    float dy_lb = gToLb(cal[calN-1].g - cal[calN-2].g);
    return (dx != 0) ? (dy_lb / dx) : 0.0f;
  }
  for (uint8_t i = 1; i < calN; i++){
    if (mm <= cal[i].mm){
      float dx = (float)(cal[i].mm - cal[i-1].mm);
      float dy_lb = gToLb(cal[i].g - cal[i-1].g);
      return (dx != 0) ? (dy_lb / dx) : 0.0f;
    }
  }
  return 0.0f;
}

// dynamic deadband in current unit
float dynamicDeadbandUnit(uint16_t mm){
  float slope_lb_per_mm = fabsf(slopeLbPerMm(mm));
  float dyn_lb = baseDeadbandUnit() + slope_lb_per_mm * (MM_JITTER_EST * 0.5f);
  if (unitMode == UNIT_KG) return dyn_lb * 0.45359237f;
  return dyn_lb;
}

// Reset filter/display
void resetFilters(){
  g_slow           = 0.f;
  slow_valid       = false;
  w_disp           = 0.f;
  last_jump_ms     = 0;
  last_mm_for_disp = 0;
  disp_mm_valid    = false;
}

// ----------------------------------------------------------------------
//  NVS: profiles + calibration storage (namespace "scale")
// ----------------------------------------------------------------------
void loadProfilesMeta(){
  profileCount  = 0;
  activeProfile = -1;

  if (!prefs.begin("scale", true)) return;

  profileCount  = prefs.getUChar("pcount", 0);
  if (profileCount > MAX_PROFILES) profileCount = MAX_PROFILES;

  activeProfile = (int8_t)prefs.getChar("active", -1);
  String u = prefs.getString("unit", "lb");
  unitMode = (u == "kg") ? UNIT_KG : UNIT_LB;

  for (uint8_t i = 0; i < profileCount; ++i){
    String pref = "p" + String(i) + "_";
    profiles[i].name   = prefs.getString((pref + "name").c_str(), "");
    uint8_t n          = prefs.getUChar((pref + "n").c_str(), 0);
    profiles[i].hasCal = (n > 0);
  }

  prefs.end();
}

// Load calibration points for one profile index
bool loadProfile(uint8_t idx){
  if (!prefs.begin("scale", true)) return false;
  if (idx >= profileCount) { prefs.end(); return false; }

  String pref = "p" + String(idx) + "_";
  uint8_t n = prefs.getUChar((pref + "n").c_str(), 0);
  if (n > CAL_MAX) n = CAL_MAX;

  calN = 0;
  for (uint8_t j = 0; j < n; ++j){
    String km = pref + "m" + String(j);
    String kg = pref + "g" + String(j);
    cal[j].mm = prefs.getUShort(km.c_str(), 0);
    cal[j].g  = prefs.getFloat(kg.c_str(), 0.f);
    calN++;
  }
  prefs.end();

  // sort by mm asc
  for (uint8_t i = 0; i < calN; ++i){
    for (uint8_t j = i+1; j < calN; ++j){
      if (cal[j].mm < cal[i].mm){
        CalPt t = cal[i]; cal[i] = cal[j]; cal[j] = t;
      }
    }
  }

  resetFilters();
  return true;
}

// Find a slot to store a profile (reuse deleted/empty slots if possible)
uint8_t allocProfileSlot(){
  for (uint8_t i = 0; i < MAX_PROFILES; ++i){
    if (i >= profileCount) return i;
    if (profiles[i].name.length() == 0 && !profiles[i].hasCal) return i;
  }
  return MAX_PROFILES - 1; // fallback overwrite last
}

// Save current cal[] into a profile idx with a name
bool saveActiveCalAsProfile(uint8_t idx, const String& name){
  if (!prefs.begin("scale", false)) return false;

  if (idx >= MAX_PROFILES){
    prefs.end();
    return false;
  }

  if (idx >= profileCount) {
    profileCount = idx + 1;
  }

  prefs.putUChar("pcount", profileCount);
  prefs.putChar("active", (char)idx);
  prefs.putString("unit", (unitMode == UNIT_KG) ? "kg" : "lb");

  String pref = "p" + String(idx) + "_";
  prefs.putString((pref + "name").c_str(), name);
  prefs.putUChar((pref + "n").c_str(), calN);

  for (uint8_t j = 0; j < calN; ++j){
    String km = pref + "m" + String(j);
    String kg = pref + "g" + String(j);
    prefs.putUShort(km.c_str(), cal[j].mm);
    prefs.putFloat(kg.c_str(),  cal[j].g);
  }

  prefs.end();

  profiles[idx].name   = name;
  profiles[idx].hasCal = (calN > 0);
  activeProfile        = idx;
  return true;
}

// Save current cal into active profile (or create default / reuse slot)
void saveActiveCalibrationToStorage(){
  uint8_t idx;
  if (activeProfile < 0) {
    idx = allocProfileSlot();
    String defaultName = "Profile " + String(idx);
    saveActiveCalAsProfile(idx, defaultName);
  } else {
    idx = (uint8_t)activeProfile;
    String nm = profiles[idx].name;
    if (nm.length() == 0) nm = "Profile " + String(idx);
    saveActiveCalAsProfile(idx, nm);
  }
}

// ----------------------------------------------------------------------
//  Display Logic (EMA + dynamic deadband + mm trigger)
// ----------------------------------------------------------------------
void refreshFilters(){
  if (ranger.oor()) return;
  if (calN == 0) {
    w_disp = 0.0f;
    return;
  }

  uint16_t mm   = ranger.mmMedian();
  float    g_in = gramsFromMM(mm);

  if (slow_valid && fabsf(g_in - g_slow) > jumpThreshG()){
    last_jump_ms = millis();
  }

  float alpha = ALPHA_SLOW;
  if (millis() - last_jump_ms < 1500) {
    alpha = ALPHA_FAST;
  }

  if (!slow_valid){
    g_slow = g_in;
    slow_valid = true;
  } else {
    g_slow += alpha * (g_in - g_slow);
  }

  float w_cur = unitFromGrams(g_slow);
  float db    = dynamicDeadbandUnit(mm);

  if (!disp_mm_valid){
    w_disp           = w_cur;
    last_mm_for_disp = mm;
    disp_mm_valid    = true;
    return;
  }

  if ((uint16_t)abs((int)mm - (int)last_mm_for_disp) >= MM_STEP_TRIGGER){
    w_disp           = w_cur;
    last_mm_for_disp = mm;
    return;
  }

  if (!isnan(w_cur) && (fabsf(w_cur - w_disp) >= db)) {
    w_disp           = w_cur;
    last_mm_for_disp = mm;
  }
}

// ----------------------------------------------------------------------
//  HTML: Home (readout)
// ----------------------------------------------------------------------
const char HOME_HTML[] PROGMEM = R"HTML(
<!doctype html><html><head>
<meta name=viewport content="width=device-width,initial-scale=1">
<title>Weight</title>
<style>
  :root{--bg:#0f1115;--card:#171a21;--ink:#e9eef5;--mut:#9aa5b1;--acc:#4fb3ff}
  *{box-sizing:border-box} body{margin:0;background:var(--bg);color:var(--ink);font:16px/1.4 system-ui,Arial;min-height:100vh}
  .bar{position:fixed;top:0;left:0;right:0;display:flex;justify-content:space-between;align-items:center;padding:12px 16px}
  .bar-title{color:var(--mut);font-size:14px}
  .bar a{background:var(--acc);color:#001825;text-decoration:none;font-weight:700;border-radius:10px;padding:8px 12px;border:0;cursor:pointer}
  .wrap{display:flex;align-items:flex-start;justify-content:center;min-height:100vh;padding-top:64px}
  .card{background:var(--card);border-radius:16px;padding:20px 26px;text-align:center;min-width:280px}
  h1{margin:0 0 6px;font-size:18px;color:var(--mut);font-weight:600}
  .big{font-size:56px;font-weight:800;margin:4px 0}
  .sub{color:var(--mut);margin-top:6px}
  .prof{margin-top:8px;font-size:14px;color:var(--mut)}
  .prof span{color:var(--ink);font-weight:600}
</style>
</head><body>
  <div class=bar>
    <div class=bar-title>Model scale</div>
    <a href="/cal">Calibrate / Profiles</a>
  </div>
  <div class=wrap>
    <div class=card>
      <h1>Current Weight</h1>
      <div id=val class=big>--</div>
      <div class=sub>Distance: <span id=mm>--</span> mm</div>
      <div class=prof>Profile: <span id=profName>none</span></div>
    </div>
  </div>
<script>
async function getJSON(u){ const r=await fetch(u,{cache:'no-store'}); return r.json(); }
async function refresh(){
  try{
    const s=await getJSON('/state');
    const val=document.getElementById('val');
    const mm=document.getElementById('mm');
    const pn=document.getElementById('profName');
    if(s.oor || !s.hasCal){
      val.textContent='--';
      mm.textContent='--';
    }else{
      const fixed=(s.unit==='kg')?3:2;
      val.textContent = s.w_disp.toFixed(fixed)+' '+s.unit;
      mm.textContent  = s.mm_med;
    }
    pn.textContent = s.profileName || 'none';
  }catch(e){}
}
setInterval(refresh,900); refresh();
</script>
</body></html>
)HTML";

// ----------------------------------------------------------------------
//  HTML: Calibration & profiles page
// ----------------------------------------------------------------------
const char CAL_HTML[] PROGMEM = R"HTML(
<!doctype html><html><head>
<meta name=viewport content="width=device-width,initial-scale=1">
<title>Calibration & Profiles</title>
<style>
  :root{--bg:#0f1115;--card:#171a21;--ink:#e9eef5;--mut:#9aa5b1;--acc:#4fb3ff}
  *{box-sizing:border-box}
  body{
    margin:0;
    background:var(--bg);
    color:var(--ink);
    font:16px/1.4 system-ui,Arial;
  }
  .wrap{max-width:920px;margin:0 auto;padding:20px}
  .row{display:flex;gap:8px;align-items:center;flex-wrap:wrap;justify-content:space-between}
  .seg{display:inline-flex;border:1px solid #2a2f3a;border-radius:12px;overflow:hidden}
  .seg button{background:transparent;color:var(--ink);border:0;padding:8px 12px;cursor:pointer}
  .seg button.active{background:#2b6cf6;color:#fff}
  .card{background:var(--card);border-radius:16px;padding:18px;margin-top:12px}
  h1{margin:0 0 6px;font-size:20px}
  h2{margin:0 0 6px;font-size:18px;color:var(--mut)}
  input[type=number],input[type=text]{
    background:#0c0f14;
    color:var(--ink);
    border:1px solid #2a2f3a;
    border-radius:10px;
    padding:8px 10px;
  }
  input[type=number]{width:140px}
  input[type=text]{width:220px}
  button{
    background:var(--acc);
    border:0;
    color:#001825;
    border-radius:10px;
    padding:8px 12px;
    font-weight:700;
    cursor:pointer;
  }
  button.alt{background:#263042;color:var(--ink)}
  button.danger{background:#b54343;color:#fff}
  table{width:100%;border-collapse:collapse;margin-top:10px}
  th,td{padding:6px;border-bottom:1px solid #232a36;text-align:left;color:var(--mut);font-size:14px}
  a.link{color:#9cc9ff;text-decoration:none}
  .pill{display:inline-block;padding:2px 8px;border-radius:999px;font-size:12px;background:#263042;color:var(--mut)}
</style>
</head><body><div class=wrap>
  <div class=row>
    <div><a class=link href="/">&larr; Back to weight</a></div>
    <div class=seg>
      <button id=btnKg>kg</button>
      <button id=btnLb>lb</button>
    </div>
  </div>

  <div class=card>
    <h1>Profiles</h1>
    <div class=row style="margin-top:6px;gap:10px">
      <div>
        <label style="font-size:14px;color:var(--mut)">Active profile:</label>
        <select id=profSel></select>
        <span id=profStatus class=pill></span>
      </div>
      <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center">
        <button id=btnUseProf class=alt>Use selected</button>
        <button id=btnViewProf class=alt>View calibration</button>
        <button id=btnNewProf class=alt>Add new profile</button>
        <button id=btnDelProf class="danger">Delete profile</button>
      </div>
    </div>
  </div>

  <!-- Calibration card: used for both edit and read-only view -->
  <div class=card id=calCard style="display:none">
    <h2>Calibration (<span id=unitLbl>lb</span>)</h2>
    <p style="color:var(--mut);font-size:14px;margin:4px 0 10px">
      1) Place a known weight, enter its value, then click
      <strong>Capture 5s average</strong>. The ESP32 will average the distance for ~5 seconds
      and store that point.<br>
      2) Repeat at different weights. 3) Click <strong>Save calibration</strong> to keep changes
      in this profile.
    </p>

    <!-- This row is HIDDEN in view-only mode -->
    <div class=row style="gap:10px;margin-top:6px" id=calControlsRow>
      <input id=win type=number step=0.01 placeholder="weight">
      <button id=add>Capture 5s average</button>
      <button id=save class=alt>Save calibration</button>
      <button id=clear class=danger>Clear points</button>
    </div>

    <table id=tbl>
      <thead><tr><th>#</th><th>mm</th><th>value</th><th></th></tr></thead>
      <tbody></tbody>
    </table>

    <!-- Name row: only used in "add new profile" flow, after Save calibration -->
    <div class=row id=nameRow style="margin-top:14px;gap:10px;display:none">
      <input id=profName type=text placeholder="Profile name (required)">
      <button id=btnSaveProf>Save profile</button>
    </div>
  </div>
</div>
<script>
let UNIT='lb';
const calCard        = document.getElementById('calCard');
const nameRow        = document.getElementById('nameRow');
const calControlsRow = document.getElementById('calControlsRow');

let newProfileMode   = false;   // true only while adding a new profile
let calibrationSaved = false;   // true after "Save calibration" in new-profile flow
let viewOnlyMode     = false;   // true when just viewing an existing profile

async function getJSON(u){ const r=await fetch(u,{cache:'no-store'}); return r.json(); }

// ---------- Unit toggle ----------
function setUnitUI(u){
  UNIT=u;
  document.getElementById('unitLbl').textContent = u;
  const step = (u==='kg')? '0.001':'0.01';
  document.getElementById('win').setAttribute('step', step);
  document.getElementById('btnKg').classList.toggle('active', u==='kg');
  document.getElementById('btnLb').classList.toggle('active', u==='lb');
}
async function refreshUnitFromState(){
  const s = await getJSON('/unit');
  setUnitUI(s.unit);
}

// ---------- Calibration points ----------
async function loadPoints(){
  const t=document.querySelector('#tbl tbody'); t.innerHTML='';
  const p=await getJSON('/cal/list');
  setUnitUI(p.unit);
  (p.points||[]).forEach(pt=>{
    const tr=document.createElement('tr');
    const fixed=(p.unit==='kg')?3:2;
    let actionHtml = "";
    if (!viewOnlyMode){
      actionHtml = `<button class="alt" data-idx="${pt.i}">delete</button>`;
    }
    tr.innerHTML =
      `<td>${pt.i}</td><td>${pt.mm}</td>` +
      `<td>${pt.val.toFixed(fixed)} ${p.unit}</td>` +
      `<td>${actionHtml}</td>`;
    t.appendChild(tr);
  });

  // Only wire up delete buttons when NOT in view-only mode
  if (!viewOnlyMode){
    t.querySelectorAll('button[data-idx]').forEach(btn=>{
      btn.onclick = async()=>{
        const idx=btn.getAttribute('data-idx');
        await fetch('/cal/del?idx='+encodeURIComponent(idx),{method:'POST'});
        loadPoints();
      };
    });
  }
}

// ---------- Profiles ----------
async function loadProfiles(){
  const p = await getJSON('/profiles');
  const sel = document.getElementById('profSel');
  const status = document.getElementById('profStatus');
  sel.innerHTML='';
  (p.profiles||[]).forEach(pr=>{
    const opt=document.createElement('option');
    opt.value = pr.idx;
    opt.textContent = pr.name || ('Profile '+pr.idx);
    if (pr.idx === p.active) opt.selected = true;
    sel.appendChild(opt);
  });
  if (p.active>=0){
    status.textContent = "active";
  } else {
    status.textContent = "none active";
  }
}

// ---------- Calibration actions ----------
document.getElementById('add').onclick = async ()=>{
  if (viewOnlyMode) return; // safety
  const v=parseFloat(document.getElementById('win').value);
  if(isNaN(v)) return alert('Enter a weight first');
  const param = (UNIT==='kg')? ('kg='+encodeURIComponent(v)) : ('lb='+encodeURIComponent(v));
  const btn = document.getElementById('add');
  const old = btn.textContent;
  btn.textContent = 'Capturing... (~5s)';
  btn.disabled = true;
  try{
    const r = await fetch('/cal/add?'+param,{method:'POST'});
    if(!r.ok){ alert('Capture failed'); }
  }finally{
    btn.textContent = old;
    btn.disabled = false;
  }
  document.getElementById('win').value='';
  loadPoints();
};

document.getElementById('save').onclick  = async ()=>{
  if (viewOnlyMode) return; // no saving in view-only mode
  await fetch('/cal/save',{method:'POST'});
  await loadProfiles();
  await loadPoints();
  if (newProfileMode){
    // after calibration saved in "add new profile" flow, show naming row
    calibrationSaved = true;
    nameRow.style.display = 'flex';
  }
};

document.getElementById('clear').onclick = async ()=>{
  if (viewOnlyMode) return;
  await fetch('/cal/clear',{method:'POST'});
  loadPoints();
};

// ---------- Unit buttons ----------
document.getElementById('btnKg').onclick = async ()=>{
  await fetch('/unit/set?u=kg',{method:'POST'});
  await refreshUnitFromState(); await loadPoints();
};
document.getElementById('btnLb').onclick = async ()=>{
  await fetch('/unit/set?u=lb',{method:'POST'});
  await refreshUnitFromState(); await loadPoints();
};

// ---------- Profile buttons ----------
document.getElementById('btnUseProf').onclick = async ()=>{
  const sel=document.getElementById('profSel');
  if(!sel.value) return;
  await fetch('/profiles/select?idx='+encodeURIComponent(sel.value),{method:'POST'});
  newProfileMode   = false;
  calibrationSaved = false;
  viewOnlyMode     = false;
  calCard.style.display = 'none';
  calControlsRow.style.display = 'flex';
  nameRow.style.display = 'none';
  document.getElementById('profName').value = '';
  await loadProfiles();
  await loadPoints();
};

document.getElementById('btnNewProf').onclick = async ()=>{
  await fetch('/profiles/new',{method:'POST'});
  newProfileMode   = true;
  calibrationSaved = false;
  viewOnlyMode     = false;
  document.getElementById('profName').value = '';
  calCard.style.display = 'block';   // show calibration UI
  calControlsRow.style.display = 'flex'; // editing controls visible
  nameRow.style.display = 'none';    // naming waits until Save calibration
  await loadProfiles();
  await loadPoints();
};

document.getElementById('btnDelProf').onclick = async ()=>{
  const sel=document.getElementById('profSel');
  if(!sel.value) return alert('No profile selected');
  if(!confirm('Delete this profile?')) return;
  await fetch('/profiles/delete?idx='+encodeURIComponent(sel.value),{method:'POST'});
  newProfileMode   = false;
  calibrationSaved = false;
  viewOnlyMode     = false;
  calCard.style.display = 'none';
  calControlsRow.style.display = 'flex';
  nameRow.style.display = 'none';
  document.getElementById('profName').value = '';
  await loadProfiles();
  await loadPoints();
};

document.getElementById('btnViewProf').onclick = async ()=>{
  const sel=document.getElementById('profSel');
  if(!sel.value) return alert('No profile selected');
  // Make that profile the working one (and also the active one used for weight readout)
  await fetch('/profiles/select?idx='+encodeURIComponent(sel.value),{method:'POST'});
  newProfileMode   = false;
  calibrationSaved = false;
  viewOnlyMode     = true;
  document.getElementById('profName').value = '';
  calCard.style.display = 'block';        // show calibration card
  calControlsRow.style.display = 'none';  // hide capture/save/clear
  nameRow.style.display = 'none';         // no naming in view-only
  await loadProfiles();
  await loadPoints();
};

// ---------- Save profile name (MANDATORY for new profile) ----------
document.getElementById('btnSaveProf').onclick = async ()=>{
  if (!newProfileMode){
    alert('This save is only for a new profile.');
    return;
  }
  if (!calibrationSaved){
    alert('Please click "Save calibration" first.');
    return;
  }
  const nameInput = document.getElementById('profName');
  const name = nameInput.value.trim();
  if (!name){
    alert('Profile name is required.');
    return;
  }
  const body = new URLSearchParams();
  body.set('name', name);
  const r = await fetch('/profiles/save',{method:'POST',body});
  if (!r.ok){
    alert('Saving profile failed.');
    return;
  }
  // After successful save: exit "add new" flow and hide calibration + naming
  newProfileMode   = false;
  calibrationSaved = false;
  viewOnlyMode     = false;
  calCard.style.display = 'none';
  calControlsRow.style.display = 'flex';
  nameRow.style.display = 'none';
  nameInput.value = '';
  await loadProfiles();
  await loadPoints();
};

// ---------- Init ----------
refreshUnitFromState();
loadProfiles();
loadPoints();
</script>
</body></html>
)HTML";




// ----------------------------------------------------------------------
//  HTTP Handlers
// ----------------------------------------------------------------------
void handleHome(){
  server.send(200, "text/html", HOME_HTML);
}
void handleCalPage(){
  server.send(200, "text/html", CAL_HTML);
}

void handleState(){
  ranger.update();
  refreshFilters();

  const bool oor  = ranger.oor();
  const uint16_t mm = ranger.mmMedian();
  bool hasCal = (calN > 0);

  String s = "{";
  s += "\"unit\":\""; s += unitName(); s += "\",";
  s += "\"oor\":";      s += (oor ? "true" : "false"); s += ",";
  s += "\"mm_med\":";   s += String(mm); s += ",";
  s += "\"w_disp\":";   s += String(w_disp, 6); s += ",";
  s += "\"hasCal\":";   s += (hasCal ? "true" : "false"); s += ",";
  s += "\"profileName\":\"";
  if (activeProfile >= 0 && activeProfile < profileCount){
    s += profiles[activeProfile].name;
  }
  s += "\"}";
  server.send(200, "application/json", s);
}

void handleCalList(){
  String s = "{\"unit\":\""; s += unitName(); s += "\",\"points\":[";
  for (uint8_t i = 0; i < calN; i++){
    if (i) s += ",";
    s += "{\"i\":";  s += i;
    s += ",\"mm\":"; s += cal[i].mm;
    s += ",\"val\":"; s += String(unitFromGrams(cal[i].g), 6);
    s += "}";
  }
  s += "]}";
  server.send(200, "application/json", s);
}

// 5-second average capture
void handleCalAdd(){
  float g = NAN;
  if (server.hasArg("kg"))      g = server.arg("kg").toFloat() * 1000.0f;
  else if (server.hasArg("lb")) g = server.arg("lb").toFloat() * G_PER_LB;
  else if (server.hasArg("g"))  g = server.arg("g").toFloat();
  else { server.send(400,"text/plain","missing kg/lb"); return; }
  if (isnan(g)){ server.send(400,"text/plain","bad value"); return; }

  uint32_t start  = millis();
  uint32_t acc    = 0;
  uint32_t count  = 0;

  while (millis() - start < CAL_CAPTURE_MS) {
    ranger.update();
    if (!ranger.oor()) {
      acc += ranger.mmMedian();
      count++;
    }
    delay(20);
  }

  if (count == 0) {
    server.send(500, "text/plain", "no valid distance samples");
    return;
  }

  uint16_t mm_avg = (uint16_t)(acc / count);
  insertCal(mm_avg, g);

  g_slow           = g;
  slow_valid       = true;
  w_disp           = unitFromGrams(g);
  last_mm_for_disp = mm_avg;
  disp_mm_valid    = true;

  server.send(200,"application/json","{\"ok\":true}");
}

void handleCalClear(){
  clearCalArray();
  resetFilters();
  server.send(200,"application/json","{\"ok\":true}");
}

void handleCalSave(){
  saveActiveCalibrationToStorage();
  server.send(200,"application/json","{\"ok\":true}");
}

void handleCalDel(){
  if (!server.hasArg("idx")) { server.send(400,"text/plain","missing idx"); return; }
  int idx = server.arg("idx").toInt();
  if (idx < 0 || idx >= (int)calN) { server.send(400,"text/plain","bad idx"); return; }
  deleteCalAt((uint8_t)idx);
  server.send(200,"application/json","{\"ok\":true}");
}

void handleUnitSet(){
  if (!server.hasArg("u")){ server.send(400,"text/plain","missing u=kg|lb"); return; }
  String u = server.arg("u");
  unitMode = (u=="kg") ? UNIT_KG : UNIT_LB;

  if (prefs.begin("scale", false)) {
    prefs.putString("unit", (unitMode==UNIT_KG)?"kg":"lb");
    prefs.end();
  }

  if (slow_valid){
    w_disp = unitFromGrams(g_slow);
  }

  server.send(200,"application/json","{\"ok\":true}");
}
void handleUnitGet(){
  String s = "{\"unit\":\""; s += unitName(); s += "\"}";
  server.send(200,"application/json",s);
}

void handleDistance(){
  ranger.update();
  if (ranger.oor()) server.send(200,"text/plain","out_of_range");
  else              server.send(200,"text/plain",String(ranger.mmMedian()));
}

void handleProfilesList(){
  String s = "{\"unit\":\""; s += unitName(); s += "\",";
  s += "\"active\":"; s += activeProfile; s += ",";
  s += "\"profiles\":[";
  bool first = true;
  for (uint8_t i = 0; i < profileCount; ++i){
    if (profiles[i].name.length() == 0 && !profiles[i].hasCal) continue; // deleted/empty
    if (!first) s += ",";
    first = false;
    s += "{\"idx\":"; s += i; s += ",";
    s += "\"name\":\""; s += profiles[i].name; s += "\",";
    s += "\"hasCal\":"; s += (profiles[i].hasCal ? "true" : "false");
    s += "}";
  }
  s += "]}";
  server.send(200, "application/json", s);
}

void handleProfileSave(){
  String name = "";
  if (server.hasArg("name")) name = server.arg("name");
  name.trim();
  if (name.length() == 0) {
    uint8_t idxGuess = (activeProfile >= 0) ? (uint8_t)activeProfile : allocProfileSlot();
    name = "Profile " + String(idxGuess);
  }

  uint8_t idx;
  if (activeProfile < 0) {
    idx = allocProfileSlot();
  } else {
    idx = (uint8_t)activeProfile;
  }

  saveActiveCalAsProfile(idx, name);
  server.send(200,"application/json","{\"ok\":true}");
}

void handleProfileSelect(){
  if (!server.hasArg("idx")) { server.send(400,"text/plain","missing idx"); return; }
  int idx = server.arg("idx").toInt();
  if (idx < 0 || idx >= (int)profileCount) { server.send(400,"text/plain","bad idx"); return; }

  if (!loadProfile((uint8_t)idx)) {
    server.send(500,"text/plain","failed to load profile");
    return;
  }

  if (prefs.begin("scale", false)) {
    prefs.putChar("active", (char)idx);
    prefs.end();
  }
  activeProfile = idx;

  server.send(200,"application/json","{\"ok\":true}");
}

// start a brand-new unsaved profile
void handleProfileNew(){
  activeProfile = -1;
  clearCalArray();
  resetFilters();
  server.send(200,"application/json","{\"ok\":true}");
}

// delete a profile (hide it from list and clear if active)
void handleProfileDelete(){
  if (!server.hasArg("idx")) { server.send(400,"text/plain","missing idx"); return; }
  int idx = server.arg("idx").toInt();
  if (idx < 0 || idx >= (int)profileCount) { server.send(400,"text/plain","bad idx"); return; }

  if (prefs.begin("scale", false)) {
    String pref = "p" + String(idx) + "_";
    prefs.putUChar((pref + "n").c_str(), 0);
    prefs.putString((pref + "name").c_str(), "");
    char act = prefs.getChar("active", -1);
    if (act == idx) {
      prefs.putChar("active", -1);
    }
    prefs.end();
  }

  profiles[idx].name   = "";
  profiles[idx].hasCal = false;

  if (activeProfile == idx) {
    activeProfile = -1;
    clearCalArray();
    resetFilters();
  }

  server.send(200,"application/json","{\"ok\":true}");
}

// ----------------------------------------------------------------------
//  Setup / Loop
// ----------------------------------------------------------------------
void setup(){
  Serial.begin(115200);
  Serial.println(F("\nModel-scale Distance→Weight (multi profiles + 5s averaged calibration + delete)"));
  Serial.println(F("SDA=22  SCL=21"));

  ranger.begin();
  loadProfilesMeta();

  if (profileCount > 0 && activeProfile >= 0 && activeProfile < profileCount) {
    if (!loadProfile((uint8_t)activeProfile)) {
      clearCalArray();
      resetFilters();
    }
  } else {
    clearCalArray();
    resetFilters();
  }

  WiFi.mode(WIFI_AP);
  WiFi.softAP(AP_SSID, AP_PASS);
  Serial.print(F("AP IP: ")); Serial.println(WiFi.softAPIP());

  server.on("/",                handleHome);
  server.on("/cal",             handleCalPage);
  server.on("/state",           handleState);
  server.on("/cal/list",        handleCalList);
  server.on("/cal/add",   HTTP_POST, handleCalAdd);
  server.on("/cal/clear", HTTP_POST, handleCalClear);
  server.on("/cal/save",  HTTP_POST, handleCalSave);
  server.on("/cal/del",   HTTP_POST, handleCalDel);
  server.on("/unit/set",  HTTP_POST, handleUnitSet);
  server.on("/unit",            handleUnitGet);
  server.on("/distance",        handleDistance);
  server.on("/profiles",        handleProfilesList);
  server.on("/profiles/save",   HTTP_POST, handleProfileSave);
  server.on("/profiles/select", HTTP_POST, handleProfileSelect);
  server.on("/profiles/new",    HTTP_POST, handleProfileNew);
  server.on("/profiles/delete", HTTP_POST, handleProfileDelete);

  server.begin();
  Serial.println(F("Web server ready: / (readout), /cal (calibration)"));
}

void loop(){
  ranger.update();
  refreshFilters();
  server.handleClient();
}
