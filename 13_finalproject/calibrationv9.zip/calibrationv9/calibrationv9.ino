#include <Wire.h>
#include <WiFi.h>
#include <WebServer.h>
#include <Preferences.h>
#include <Adafruit_VL53L0X.h>
#include <math.h>

// ---------------- Pins & Wi-Fi ----------------
static const uint8_t SDA_PIN = 22;  // per your wiring
static const uint8_t SCL_PIN = 21;

const char* AP_SSID = "ESP32-Distance";
const char* AP_PASS = "distance1";

// ---------------- Sensor & Filter Tuning ------------------
// Tuned for 0–2000 lb range; aim to detect ~5 mm changes
static const uint32_t SAMPLE_MS     = 200;   // sampling rate
static const uint8_t  MED_WIN       = 11;    // median window (odd)
static const float    MM_JITTER_EST = 5.0f;  // expected noise (mm)

// Smoothing
static const float    G_PER_LB      = 453.59237f;
static const float    ALPHA_SLOW    = 0.02f; // baseline EMA in grams
static const float    ALPHA_FAST    = 0.08f; // temporarily after big jump

// Deadbands (base; dynamic part added from slope)
static const float    BASE_DEAD_LB  = 0.50f; // smaller so small changes get through
static const float    BASE_DEAD_KG  = 0.25f; // ~0.55 lb

// “Big jump” heuristic just to momentarily speed EMA (no locking)
static const float    JUMP_LB       = 25.0f;

// **New**: force an update if median distance moves by >= this many mm
static const uint16_t MM_STEP_TRIGGER = 5;

// ---------------- Web & Storage --------------
WebServer   server(80);
Preferences prefs;

// ---------------- Sensor Task ----------------
class VL53Task {
public:
  VL53Task(uint8_t sda, uint8_t scl, uint32_t dt_ms)
  : _sda(sda), _scl(scl), _dt(dt_ms) {}

  bool begin() {
    Wire.begin(_sda, _scl);
    Wire.setClock(100000);
    _ok = _lox.begin(0x29, false);
    if (!_ok) Serial.println(F("VL53L0X init failed"));
    return _ok;
  }

  void update() {
    if (!_ok) return;
    uint32_t now = millis();
    if (now - _last < _dt) return;
    _last = now;

    VL53L0X_RangingMeasurementData_t m;
    _lox.rangingTest(&m, false);
    if (m.RangeStatus == 4) {
      _oor = true;
      pushMM(0);
    } else {
      _oor = false;
      pushMM((uint16_t)m.RangeMilliMeter);
    }
  }

  bool     oor()      const { return _oor; }
  uint16_t mmMedian() const { return _mm_med; }

private:
  void pushMM(uint16_t mm) {
    _buf[_i] = mm;
    _i = (_i + 1) % MED_WIN;
    if (_count < MED_WIN) _count++;

    uint16_t tmp[MED_WIN];
    for (uint8_t k=0; k<_count; ++k) tmp[k] = _buf[k];
    // insertion sort
    for (uint8_t a=1; a<_count; ++a){
      uint16_t key = tmp[a]; int8_t b=a-1;
      while (b>=0 && tmp[b] > key){ tmp[b+1]=tmp[b]; --b; }
      tmp[b+1] = key;
    }
    _mm_med = tmp[_count ? (_count-1)/2 : 0];
  }

  Adafruit_VL53L0X _lox;
  uint8_t  _sda, _scl;
  uint32_t _dt, _last = 0;
  bool     _ok=false, _oor=true;

  uint16_t _buf[MED_WIN] = {0};
  uint8_t  _i=0, _count=0;
  uint16_t _mm_med=0;
};

VL53Task ranger(SDA_PIN, SCL_PIN, SAMPLE_MS);

// ---------------- Calibration (stored in grams) -----------
struct CalPt { uint16_t mm; float g; };
static const uint8_t CAL_MAX = 64;
CalPt  cal[CAL_MAX];
uint8_t calN = 0;

// Units
enum UnitMode : uint8_t { UNIT_KG = 0, UNIT_LB = 1 };
UnitMode unitMode = UNIT_LB;  // default to lb

float gramsFromUnit(float v){
  return (unitMode == UNIT_KG) ? (v * 1000.0f) : (v * G_PER_LB);
}
float unitFromGrams(float g){
  return (unitMode == UNIT_KG) ? (g / 1000.0f) : (g / G_PER_LB);
}
float baseDeadbandUnit(){ return (unitMode == UNIT_KG) ? BASE_DEAD_KG : BASE_DEAD_LB; }
float lbToG(float lb){ return lb * G_PER_LB; }
float gToLb(float g){ return g / G_PER_LB; }
const char* unitName(){ return (unitMode == UNIT_KG) ? "kg" : "lb"; }

// Prefs
void loadCal() {
  calN = 0;
  if (!prefs.begin("vl53scale", true)) return;
  calN = prefs.getUChar("n", 0);
  if (calN > CAL_MAX) calN = 0;
  for (uint8_t i=0; i<calN; ++i) {
    char kmm[8], kg[8];
    snprintf(kmm,sizeof(kmm),"m%u",i);
    snprintf(kg, sizeof(kg), "g%u",i);
    cal[i].mm = prefs.getUShort(kmm, 0);
    cal[i].g  = prefs.getFloat(kg,  0.f);
  }
  String u = prefs.getString("unit", "lb");
  unitMode = (u == "kg") ? UNIT_KG : UNIT_LB;
  prefs.end();
  // sort by mm asc
  for (uint8_t i=0;i<calN;i++){
    for (uint8_t j=i+1;j<calN;j++){
      if (cal[j].mm < cal[i].mm){ CalPt t=cal[i]; cal[i]=cal[j]; cal[j]=t; }
    }
  }
}
void saveCal() {
  if (!prefs.begin("vl53scale", false)) return;
  prefs.putUChar("n", calN);
  for (uint8_t i=0; i<calN; ++i) {
    char kmm[8], kg[8];
    snprintf(kmm,sizeof(kmm),"m%u",i);
    snprintf(kg, sizeof(kg), "g%u",i);
    prefs.putUShort(kmm, cal[i].mm);
    prefs.putFloat( kg,  cal[i].g);
  }
  prefs.putString("unit", (unitMode==UNIT_KG)?"kg":"lb");
  prefs.end();
}
void clearCal(){ calN=0; saveCal(); }
void insertCal(uint16_t mm, float g){
  uint8_t pos=0; while (pos<calN && cal[pos].mm < mm) pos++;
  if (calN < CAL_MAX){
    for (int i=calN; i>pos; --i) cal[i]=cal[i-1];
    cal[pos] = {mm, g};
    calN++;
  }else{
    cal[(pos==calN)?(calN-1):pos] = {mm,g};
  }
}

// piecewise linear grams (clamped)
float gramsFromMM(uint16_t mm){
  if (calN==0) return 0.f;
  if (calN==1) return cal[0].g;
  if (mm <= cal[0].mm)        return cal[0].g;
  if (mm >= cal[calN-1].mm)   return cal[calN-1].g;
  for (uint8_t i=1;i<calN;i++){
    if (mm <= cal[i].mm){
      float x0=cal[i-1].mm, y0=cal[i-1].g;
      float x1=cal[i].mm,   y1=cal[i].g;
      float t=(mm-x0)/(x1-x0);
      return y0 + t*(y1-y0);
    }
  }
  return cal[calN-1].g;
}

// local slope in lb/mm near mm (from adjacent segment)
float slopeLbPerMm(uint16_t mm){
  if (calN < 2) return 0.0f;
  if (mm <= cal[0].mm){
    float dx = (float)(cal[1].mm - cal[0].mm);
    float dy_lb = gToLb(cal[1].g - cal[0].g);
    return (dx != 0) ? (dy_lb / dx) : 0.0f;
  }
  if (mm >= cal[calN-1].mm){
    float dx = (float)(cal[calN-1].mm - cal[calN-2].mm);
    float dy_lb = gToLb(cal[calN-1].g - cal[calN-2].g);
    return (dx != 0) ? (dy_lb / dx) : 0.0f;
  }
  for (uint8_t i=1;i<calN;i++){
    if (mm <= cal[i].mm){
      float dx = (float)(cal[i].mm - cal[i-1].mm);
      float dy_lb = gToLb(cal[i].g - cal[i-1].g);
      return (dx != 0) ? (dy_lb / dx) : 0.0f;
    }
  }
  return 0.0f;
}

// ---------------- Display Logic (no “settling” state) -----
float g_slow = 0.f;     bool slow_valid = false;
float w_disp = 0.f;     // what we show (current unit)
uint32_t last_jump_ms = 0;

// track last mm associated with the displayed value, to allow 5 mm trigger
uint16_t last_mm_for_disp = 0;
bool     disp_mm_valid    = false;

float jumpThreshG(){ return lbToG(JUMP_LB); }

// dynamic deadband in *current unit*
float dynamicDeadbandUnit(uint16_t mm){
  float slope_lb_per_mm = fabsf(slopeLbPerMm(mm));
  float dyn_lb = baseDeadbandUnit() + slope_lb_per_mm * (MM_JITTER_EST * 0.5f);
  if (unitMode == UNIT_KG) return dyn_lb * 0.45359237f;
  return dyn_lb;
}

void refreshFilters(){
  if (ranger.oor()) return;

  uint16_t mm   = ranger.mmMedian();
  float    g_in = gramsFromMM(mm);

  // detect big jump → temporarily speed EMA to catch up
  if (slow_valid && fabsf(g_in - g_slow) > jumpThreshG()){
    last_jump_ms = millis();
  }

  float alpha = ALPHA_SLOW;
  if (millis() - last_jump_ms < 1500) {
    alpha = ALPHA_FAST; // converge quicker for ~1.5 s after a jump
  }

  if (!slow_valid){ g_slow = g_in; slow_valid = true; }
  else            { g_slow += alpha * (g_in - g_slow); }

  float w_cur = unitFromGrams(g_slow);
  float db    = dynamicDeadbandUnit(mm);

  // First-time init
  if (!disp_mm_valid){
    w_disp = w_cur;
    last_mm_for_disp = mm;
    disp_mm_valid = true;
    return;
  }

  // **New rule:** if median distance has moved by >= 5 mm since the last display update,
  // refresh the display immediately (using the smoothed weight).
  if ((uint16_t)abs((int)mm - (int)last_mm_for_disp) >= MM_STEP_TRIGGER){
    w_disp = w_cur;
    last_mm_for_disp = mm;
    return;
  }

  // Otherwise, normal deadbanded updates
  if (!isnan(w_cur) && (fabsf(w_cur - w_disp) >= db)) {
    w_disp = w_cur;
    last_mm_for_disp = mm;
  }
}

// ---------------- HTML: Home (readout) --------------------
const char HOME_HTML[] PROGMEM = R"HTML(
<!doctype html><html><head>
<meta name=viewport content="width=device-width,initial-scale=1">
<title>Weight</title>
<style>
  :root{--bg:#0f1115;--card:#171a21;--ink:#e9eef5;--mut:#9aa5b1;--acc:#4fb3ff}
  *{box-sizing:border-box} body{margin:0;background:var(--bg);color:var(--ink);font:16px/1.4 system-ui,Arial;min-height:100vh}
  .bar{position:fixed;top:0;left:0;right:0;display:flex;justify-content:flex-end;padding:12px}
  .bar a{background:var(--acc);color:#001825;text-decoration:none;font-weight:700;border-radius:10px;padding:10px 14px}
  .wrap{display:flex;align-items:flex-start;justify-content:center;min-height:100vh;padding-top:64px}
  .card{background:var(--card);border-radius:16px;padding:20px 26px;text-align:center;min-width:280px}
  h1{margin:0 0 6px;font-size:18px;color:var(--mut);font-weight:600}
  .big{font-size:64px;font-weight:800;margin:4px 0}
  .sub{color:var(--mut);margin-top:6px}
</style>
</head><body>
  <div class=bar><a href="/cal">Calibrate</a></div>
  <div class=wrap>
    <div class=card>
      <h1>Current Weight</h1>
      <div id=val class=big>--</div>
      <div class=sub>Distance: <span id=mm>--</span> mm</div>
    </div>
  </div>
<script>
async function getJSON(u){ const r=await fetch(u,{cache:'no-store'}); return r.json(); }
async function refresh(){
  try{
    const s=await getJSON('/state');
    const val=document.getElementById('val');
    const mm=document.getElementById('mm');
    if(s.oor){
      val.textContent='out of range';
      mm.textContent='--';
    }else{
      const fixed=(s.unit==='kg')?3:2;
      val.textContent = s.w_disp.toFixed(fixed) + ' ' + s.unit;
      mm.textContent  = s.mm_med;
    }
  }catch(e){}
}
setInterval(refresh,900); refresh();
</script>
</body></html>
)HTML";

// ---------------- HTML: Calibration page ------------------
const char CAL_HTML[] PROGMEM = R"HTML(
<!doctype html><html><head>
<meta name=viewport content="width=device-width,initial-scale=1">
<title>Calibration</title>
<style>
  :root{--bg:#0f1115;--card:#171a21;--ink:#e9eef5;--mut:#9aa5b1;--acc:#4fb3ff}
  *{box-sizing:border-box} body{margin:0;background:var(--bg);color:var(--ink);font:16px/1.4 system-ui,Arial}
  .wrap{max-width:880px;margin:0 auto;padding:24px}
  .row{display:flex;gap:8px;align-items:center;flex-wrap:wrap;justify-content:space-between}
  .seg{display:inline-flex;border:1px solid #2a2f3a;border-radius:12px;overflow:hidden}
  .seg button{background:transparent;color:var(--ink);border:0;padding:8px 12px;cursor:pointer}
  .seg button.active{background:#2b6cf6;color:#fff}
  .card{background:var(--card);border-radius:16px;padding:20px;margin-top:12px}
  h1{margin:0 0 8px;font-size:22px}
  input[type=number]{background:#0c0f14;color:var(--ink);border:1px solid #2a2f3a;border-radius:10px;padding:10px 12px;width:180px}
  button{background:var(--acc);border:0;color:#001825;border-radius:10px;padding:10px 14px;font-weight:700;cursor:pointer}
  button.alt{background:#263042;color:var(--ink)}
  table{width:100%;border-collapse:collapse;margin-top:10px}
  th,td{padding:8px;border-bottom:1px solid #232a36;text-align:left;color:var(--mut)}
  a.link{color:#9cc9ff;text-decoration:none}
</style>
</head><body><div class=wrap>
  <div class=row>
    <div><a class=link href="/">&larr; Back to weight</a></div>
    <div class=seg>
      <button id=btnKg>kg</button>
      <button id=btnLb>lb</button>
    </div>
  </div>

  <div class=card>
    <h1>Calibrate (<span id=unitLbl>lb</span>)</h1>
    <div class=row style="gap:10px;margin-top:6px">
      <input id=win type=number step=0.01 placeholder="weight">
      <button id=add>Capture @ current mm</button>
      <button id=save class=alt>Save</button>
      <button id=clear class=alt>Clear</button>
    </div>
    <table id=tbl><thead><tr><th>mm</th><th>value</th></tr></thead><tbody></tbody></table>
  </div>
</div>
<script>
let UNIT='lb';
function setUnitUI(u){
  UNIT=u;
  document.getElementById('unitLbl').textContent = u;
  const step = (u==='kg')? '0.001':'0.01';
  document.getElementById('win').setAttribute('step', step);
  document.getElementById('btnKg').classList.toggle('active', u==='kg');
  document.getElementById('btnLb').classList.toggle('active', u==='lb');
}
async function getJSON(u){ const r=await fetch(u,{cache:'no-store'}); return r.json(); }

async function refreshUnitFromState(){
  const s = await getJSON('/unit');
  setUnitUI(s.unit);
}
async function loadPoints(){
  const t=document.querySelector('#tbl tbody'); t.innerHTML='';
  const p=await getJSON('/cal/list');
  setUnitUI(p.unit);
  (p.points||[]).forEach(pt=>{
    const tr=document.createElement('tr');
    const fixed = (p.unit==='kg') ? 3 : 2;
    tr.innerHTML = `<td>${pt.mm}</td><td>${pt.val.toFixed(fixed)} ${p.unit}</td>`;
    t.appendChild(tr);
  });
}

document.getElementById('add').onclick = async ()=>{
  const v=parseFloat(document.getElementById('win').value);
  if(isNaN(v)) return alert('Enter a weight first');
  const param = (UNIT==='kg')? ('kg='+encodeURIComponent(v)) : ('lb='+encodeURIComponent(v));
  await fetch('/cal/add?'+param,{method:'POST'});
  document.getElementById('win').value='';
  loadPoints();
};
document.getElementById('save').onclick  = async ()=>{ await fetch('/cal/save',{method:'POST'}); loadPoints(); };
document.getElementById('clear').onclick = async ()=>{ await fetch('/cal/clear',{method:'POST'}); loadPoints(); };

document.getElementById('btnKg').onclick = async ()=>{
  await fetch('/unit/set?u=kg',{method:'POST'});
  await refreshUnitFromState(); await loadPoints();
};
document.getElementById('btnLb').onclick = async ()=>{
  await fetch('/unit/set?u=lb',{method:'POST'});
  await refreshUnitFromState(); await loadPoints();
};

refreshUnitFromState(); loadPoints();
</script>
</body></html>
)HTML";

// ---------------- HTTP Handlers ----------------
void handleHome(){ server.send(200, "text/html", HOME_HTML); }
void handleCalPage(){ server.send(200, "text/html", CAL_HTML); }

void handleState(){
  // Keep the pipeline running
  ranger.update();
  refreshFilters();

  const bool oor = ranger.oor();
  const uint16_t mm = ranger.mmMedian();

  String s = "{";
  s += "\"unit\":\""; s += unitName(); s += "\",";
  s += "\"oor\":"; s += (oor?"true":"false"); s += ",";
  s += "\"mm_med\":"; s += String(mm); s += ",";
  s += "\"w_disp\":"; s += String(w_disp, 6);
  s += "}";
  server.send(200, "application/json", s);
}

void handleCalList(){
  String s = "{\"unit\":\""; s += unitName(); s += "\",\"points\":[";
  for (uint8_t i=0;i<calN;i++){
    if (i) s += ",";
    s += "{\"mm\":"; s += cal[i].mm; s += ",\"val\":"; s += String(unitFromGrams(cal[i].g), 6); s += "}";
  }
  s += "]}";
  server.send(200,"application/json",s);
}

void handleCalAdd(){
  float g = NAN;
  if (server.hasArg("kg"))      g = server.arg("kg").toFloat() * 1000.0f;
  else if (server.hasArg("lb")) g = server.arg("lb").toFloat() * G_PER_LB;
  else if (server.hasArg("g"))  g = server.arg("g").toFloat();
  else { server.send(400,"text/plain","missing kg/lb"); return; }
  if (isnan(g)){ server.send(400,"text/plain","bad value"); return; }

  uint16_t mm = ranger.mmMedian();
  insertCal(mm, g);
  saveCal();

  // Recenter EMA & display around the new point so it looks responsive
  g_slow = g; slow_valid = true;
  w_disp = unitFromGrams(g);
  last_mm_for_disp = mm; disp_mm_valid = true;

  server.send(200,"application/json","{\"ok\":true}");
}

void handleCalClear(){ clearCal(); slow_valid=false; w_disp=0; disp_mm_valid=false; server.send(200,"application/json","{\"ok\":true}"); }
void handleCalSave() { saveCal(); server.send(200,"application/json","{\"ok\":true}"); }

void handleUnitSet(){
  if (!server.hasArg("u")){ server.send(400,"text/plain","missing u=kg|lb"); return; }
  String u = server.arg("u");
  unitMode = (u=="kg") ? UNIT_KG : UNIT_LB;
  saveCal();
  if (slow_valid){
    w_disp = unitFromGrams(g_slow);
  }
  server.send(200,"application/json","{\"ok\":true}");
}
void handleUnitGet(){ String s = "{\"unit\":\""; s += unitName(); s += "\"}"; server.send(200,"application/json",s); }

// Simple legacy endpoint
void handleDistance(){
  ranger.update();
  if (ranger.oor()) server.send(200,"text/plain","out_of_range");
  else              server.send(200,"text/plain",String(ranger.mmMedian()));
}

// ---------------- Setup / Loop -----------------
void setup(){
  Serial.begin(115200);
  Serial.println(F("\nDistance→Weight (EMA + dynamic deadband + 5mm trigger)  SDA=22 SCL=21"));

  ranger.begin();
  loadCal();

  WiFi.mode(WIFI_AP);
  WiFi.softAP(AP_SSID, AP_PASS);
  Serial.print(F("AP IP: ")); Serial.println(WiFi.softAPIP());

  server.on("/",            handleHome);
  server.on("/cal",         handleCalPage);
  server.on("/state",       handleState);
  server.on("/cal/list",    handleCalList);
  server.on("/cal/add",     HTTP_POST, handleCalAdd);
  server.on("/cal/clear",   HTTP_POST, handleCalClear);
  server.on("/cal/save",    HTTP_POST, handleCalSave);
  server.on("/unit/set",    HTTP_POST, handleUnitSet);
  server.on("/unit",        handleUnitGet);
  server.on("/distance",    handleDistance); // legacy

  server.begin();
  Serial.println(F("Web server up: / and /cal"));
}

void loop(){
  // Keep things responsive even if not polled
  ranger.update();
  refreshFilters();
  server.handleClient();
}
