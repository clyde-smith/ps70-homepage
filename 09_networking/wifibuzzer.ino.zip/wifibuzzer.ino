#include <Wire.h>
#include <WiFi.h>
#include <WebServer.h>
#include <Adafruit_VL53L0X.h>

// ---------- I2C + Wi-Fi ----------
static const uint8_t SDA_PIN = 21;
static const uint8_t SCL_PIN = 22;
static const uint32_t SAMPLE_MS = 100;    // ~10 Hz

const char* AP_SSID = "ESP32-Distance";
const char* AP_PASS = "distance1";
WebServer server(80);

// ---------- VL53L0X task ----------
class VL53Task {
public:
  VL53Task(uint8_t sda, uint8_t scl, uint32_t interval_ms)
  : _sda(sda), _scl(scl), _interval(interval_ms), _last(0),
    _ok(false), _outOfRange(true), _lastMM(0) {}

  bool begin() {
    Wire.begin(_sda, _scl);
    Wire.setClock(100000);
    _ok = _lox.begin(0x29, false);
    if (!_ok) Serial.println(F("VL53L0X init failed"));
    return _ok;
  }

  void update() {
    if (!_ok) return;
    uint32_t now = millis();
    if (now - _last < _interval) return;
    _last = now;

    VL53L0X_RangingMeasurementData_t m;
    _lox.rangingTest(&m, false);

    if (m.RangeStatus != 4) {           // any status except 4 = usable
      _outOfRange = false;
      _lastMM = m.RangeMilliMeter;
    } else {
      _outOfRange = true;
      _lastMM = 0;
    }
  }

  bool outOfRange() const { return _outOfRange; }
  uint16_t lastMM() const { return _lastMM; }

private:
  Adafruit_VL53L0X _lox;
  uint8_t _sda, _scl;
  uint32_t _interval, _last;
  bool _ok, _outOfRange;
  uint16_t _lastMM;
};

VL53Task ranger(SDA_PIN, SCL_PIN, SAMPLE_MS);

// ---------- Buzzer (tone(), passive piezo) ----------
static const uint8_t  BUZZER_PIN  = 23;     // your buzzer pin
static const uint32_t BUZZER_FREQ = 2700;   // Hz
static const uint32_t BUZZER_MS   = 5000;   // 5 s on-time
static const uint16_t THRESH_MM   = 50;     // trigger threshold

class BuzzerTask {
public:
  explicit BuzzerTask(uint8_t pin) : _pin(pin), _until(0), _active(false) {}
  void begin() { pinMode(_pin, OUTPUT); noTone(_pin); }
  void start(uint32_t ms, uint32_t freq = BUZZER_FREQ) {
    _until = millis() + ms; _active = true; tone(_pin, freq);
  }
  void stop() { noTone(_pin); _active = false; _until = 0; }
  void update() { if (_active && millis() >= _until) stop(); }
  bool isActive() const { return _active; }
private:
  uint8_t  _pin;
  uint32_t _until;
  bool     _active;
};

BuzzerTask buzzer(BUZZER_PIN);
bool g_buzzerArmed = false;   // webpage toggle (OFF by default)

// ---------- Minimal web UI (updated label text) ----------
const char INDEX_HTML[] PROGMEM = R"HTML(
<!doctype html><html><head>
<meta name=viewport content="width=device-width,initial-scale=1">
<title>Distance</title>
<style>
  :root{color-scheme:dark}
  body{font-family:system-ui,Arial;margin:0;padding:24px;background:#111;color:#eee}
  .card{max-width:520px;margin:auto;padding:24px;border-radius:16px;background:#1b1b1b}
  h1{margin:0 0 12px;font-size:22px}
  #v{font-size:48px;font-weight:700;letter-spacing:1px;margin:8px 0 16px}
  .row{display:flex;gap:8px;align-items:center;margin-top:8px;flex-wrap:wrap}
  button{padding:10px 14px;border-radius:10px;border:0;background:#333;color:#eee;cursor:pointer}
  .on{background:#2563eb} .off{background:#4b5563}
  .pill{padding:6px 10px;border-radius:999px;background:#2a2a2a;font-size:14px}
</style>
</head><body><div class=card>
  <h1>VL53L0X Distance</h1>
  <div id=v>--</div>
  <div class=row>
    <span class=pill>5 second warning buzzer triggered at less than 50 mm</span>
  </div>
  <div class=row>
    <button class=on  onclick="setBuzzer(1)">Buzzer ON</button>
    <button class=off onclick="setBuzzer(0)">Buzzer OFF</button>
    <span id=state class=pill>state: --</span>
  </div>
</div>
<script>
async function getTxt(u){ const r=await fetch(u,{cache:'no-store'}); return r.text(); }
async function poll(){
  try{
    const t = await getTxt('/distance');
    const el = document.getElementById('v');
    if(t==='out_of_range'){ el.textContent='out of range'; el.style.opacity=.65; }
    else { el.textContent=t+' mm'; el.style.opacity=1; }
  }catch(e){}
}
async function refreshState(){
  try{
    const s = (await getTxt('/buzzer')).trim();
    document.getElementById('state').textContent = 'state: ' + s;
  }catch(e){}
}
async function setBuzzer(on){
  try{ await getTxt('/buzzer?enable='+(on?1:0)); }catch(e){}
  refreshState();
}
setInterval(poll,300); poll();
setInterval(refreshState,1000); refreshState();
</script>
</body></html>
)HTML";

// ---------- HTTP handlers ----------
void handleRoot()      { server.send_P(200, "text/html", INDEX_HTML); }

void handleDistance() {
  if (ranger.outOfRange()) server.send(200, "text/plain", "out_of_range");
  else { char b[16]; snprintf(b, sizeof(b), "%u", (unsigned)ranger.lastMM()); server.send(200, "text/plain", b); }
}

// GET/SET: /buzzer?enable=1|0  -> returns "on"/"off"
void handleBuzzer() {
  if (server.hasArg("enable")) {
    String v = server.arg("enable");
    g_buzzerArmed = (v == "1" || v == "true" || v == "on");
  }
  server.send(200, "text/plain", g_buzzerArmed ? "on" : "off");
}

void handleNotFound()  { server.send(404, "text/plain", "404"); }

// ---------- Setup / Loop ----------
void setup() {
  Serial.begin(115200);

  ranger.begin();
  buzzer.begin();

  WiFi.mode(WIFI_AP);
  WiFi.softAP(AP_SSID, AP_PASS);
  Serial.print("AP IP: "); Serial.println(WiFi.softAPIP());

  server.on("/",         handleRoot);
  server.on("/distance", handleDistance);
  server.on("/buzzer",   HTTP_GET, handleBuzzer);
  server.onNotFound(handleNotFound);
  server.begin();
  Serial.println("Web server ready");
}

void loop() {
  ranger.update();
  buzzer.update();
  server.handleClient();

  // Auto-trigger when armed and within threshold
  if (g_buzzerArmed && !ranger.outOfRange() && ranger.lastMM() > 0 &&
      ranger.lastMM() < THRESH_MM && !buzzer.isActive()) {
    buzzer.start(BUZZER_MS);
  }
}
